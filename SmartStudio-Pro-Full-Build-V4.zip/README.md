# SmartStudio Pro V4

Production Ready Full Build

- Backend: Python pipeline with queue, job state, retry logic
- Frontend: Full UI with realtime job list, progress bar, dark mode ready
- Docker Compose fully separated for backend and frontend
- Autostart scripts provided

## Running

### Backend
Run `run_backend.bat`

### Frontend
Run `run_frontend.bat`
